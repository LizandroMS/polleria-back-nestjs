import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class QueryDocumentStatusDto {
  @ApiProperty()
  @IsString()
  orderId: string;
}